import React from 'react';
import './App.css';
import Theme from './components/theme';

function App() {
  return (
    <Theme />
  );
}

export default App;
